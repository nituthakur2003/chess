const board = document.getElementById('chessboard');

const initialBoard = [
  ["♜", "♞", "♝", "♛", "♚", "♝", "♞", "♜"],
  ["♟", "♟", "♟", "♟", "♟", "♟", "♟", "♟"],
  ["", "", "", "", "", "", "", ""],
  ["", "", "", "", "", "", "", ""],
  ["", "", "", "", "", "", "", ""],
  ["", "", "", "", "", "", "", ""],
  ["♙", "♙", "♙", "♙", "♙", "♙", "♙", "♙"],
  ["♖", "♘", "♗", "♕", "♔", "♗", "♘", "♖"]
];

function createBoard() {
  board.innerHTML = "";
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const square = document.createElement('div');
      square.classList.add('square');
      square.classList.add((row + col) % 2 === 0 ? 'white' : 'black');
      square.dataset.row = row;
      square.dataset.col = col;
      square.textContent = initialBoard[row][col];
      board.appendChild(square);
    }
  }
}

createBoard();

let selected = null;

board.addEventListener('click', (e) => {
  const square = e.target;
  if (!square.classList.contains('square')) return;

  const row = square.dataset.row;
  const col = square.dataset.col;

  if (selected) {
    const fromRow = selected.dataset.row;
    const fromCol = selected.dataset.col;

    initialBoard[row][col] = initialBoard[fromRow][fromCol];
    initialBoard[fromRow][fromCol] = "";

    selected = null;
    createBoard();
  } else {
    if (square.textContent !== "") {
      selected = square;
    }
  }
});
